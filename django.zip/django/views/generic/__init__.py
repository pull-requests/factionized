class GenericViewError(Exception):
    """A problem in a generic view."""
    pass
